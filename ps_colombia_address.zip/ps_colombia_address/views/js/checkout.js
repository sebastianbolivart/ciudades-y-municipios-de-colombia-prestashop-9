/**
 * ps_colombia_address — checkout.js
 *
 * Adds the Colombian address hierarchy behaviour to the PrestaShop
 * address form in both the back-office and the front-office checkout.
 *
 * Responsibilities
 * ────────────────
 * 1. Detect when the user changes the State/Department dropdown.
 * 2. Request municipalities via AJAX from the module's front controller.
 * 3. Populate the municipality <select> element.
 * 4. Autofill the postal-code input from the selected municipality.
 * 5. Write the DANE code into a hidden input.
 * 6. Keep the native PrestaShop `city` field in sync so form
 *    validation and normal data-flow continue to work.
 * 7. Re-initialise after PrestaShop single-page checkout (AJAX) refreshes.
 *
 * Security
 * ────────
 * • The static shop token is sent with every request (set via Media::addJsDef).
 * • Output from the AJAX response is escaped before injection into the DOM.
 * • No eval, no innerHTML with raw server values.
 * • Content Security Policy: no inline event handlers; all listeners attached
 *   via addEventListener.
 *
 * Dependencies: vanilla JS (ES2017+). No jQuery required, but works
 * alongside it if present.
 *
 * Runtime config is injected by the module's hookDisplayHeader() into
 * window.colombiaAddressConfig:
 *   {
 *     baseUrl:            string   AJAX endpoint
 *     autofillPostal:     boolean
 *     logisticsMode:      boolean
 *     token:              string   PrestaShop static front token
 *   }
 */

'use strict';

(function () {
  // ── Guard: only run when both config and the DOM are ready ──────────────

  if (typeof window.colombiaAddressConfig === 'undefined') {
    return;
  }

  const CONFIG = window.colombiaAddressConfig;

  // ── Selectors ──────────────────────────────────────────────────────────

  /**
   * Return the address form's state/department <select>.
   * PrestaShop uses id_state in both the checkout and back-office forms.
   *
   * @returns {HTMLSelectElement|null}
   */
  function getDepartmentSelect() {
    return (
      document.querySelector('select[name="id_state"]') ||
      document.querySelector('select[name="address[id_state]"]') ||
      document.querySelector('[data-colombia-department]') ||
      document.querySelector('#id_state') ||
      null
    );
  }

  function getNativeDepartmentSelect() {
    return (
      document.querySelector('select[name="id_state"]') ||
      document.querySelector('select[name="address[id_state]"]') ||
      document.querySelector('#id_state') ||
      null
    );
  }

  function getCountrySelect() {
    return (
      document.querySelector('select[name="id_country"]') ||
      document.querySelector('select[name="address[id_country]"]') ||
      document.querySelector('#id_country') ||
      null
    );
  }

  function getCompanyField() {
    return (
      document.querySelector('input[name="company"]') ||
      document.querySelector('input[name="address[company]"]') ||
      document.querySelector('#company') ||
      null
    );
  }

  function getVatNumberField() {
    return (
      document.querySelector('input[name="vat_number"]') ||
      document.querySelector('input[name="address[vat_number]"]') ||
      document.querySelector('#vat_number') ||
      null
    );
  }

  function getAddress2Field() {
    return (
      document.querySelector('input[name="address2"]') ||
      document.querySelector('input[name="address[address2]"]') ||
      document.querySelector('#address2') ||
      null
    );
  }

  function getFieldGroup(field) {
    if (!field) return null;
    return field.closest('.form-group') || field.parentNode || null;
  }

  function moveGroupAfter(group, targetGroup) {
    if (!group || !targetGroup || group === targetGroup) return;
    const parent = targetGroup.parentNode;
    if (!parent || group.parentNode !== parent) return;

    if (targetGroup.nextSibling) {
      parent.insertBefore(group, targetGroup.nextSibling);
      return;
    }

    parent.appendChild(group);
  }

  function hideOptionalAddressFields() {
    [getCompanyField(), getVatNumberField(), getAddress2Field()].forEach(function (field) {
      const group = getFieldGroup(field);
      if (group && group.style) {
        group.style.display = 'none';
      }
    });
  }

  function reorderAddressGroups() {
    const postcodeGroup = getFieldGroup(getPostalCodeField());
    const countryGroup = getFieldGroup(getCountrySelect());
    const departmentGroup = getFieldGroup(getDepartmentSelect()) || getDynamicDepartmentGroup();
    const cityGroup = getFieldGroup(getCityField());

    if (postcodeGroup && countryGroup) {
      moveGroupAfter(countryGroup, postcodeGroup);
    }

    const currentCountryGroup = getFieldGroup(getCountrySelect());
    if (currentCountryGroup && departmentGroup) {
      moveGroupAfter(departmentGroup, currentCountryGroup);
    }

    const currentDepartmentGroup = getFieldGroup(getDepartmentSelect()) || getDynamicDepartmentGroup();
    if (currentDepartmentGroup && cityGroup) {
      moveGroupAfter(cityGroup, currentDepartmentGroup);
    }
  }

  function getSelectedOptionText(select) {
    if (!select || !select.options || select.selectedIndex < 0) return '';
    const selected = select.options[select.selectedIndex];
    if (!selected) return '';
    return String(selected.textContent || '').trim();
  }

  function normalizeLabel(label) {
    return String(label || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function isDepartmentPlaceholder(label) {
    const normalized = normalizeLabel(label);
    return normalized === '' || normalized.indexOf('seleccione un departamento') !== -1;
  }

  function getSelectedDepartmentName(select) {
    const label = getSelectedOptionText(select);
    return isDepartmentPlaceholder(label) ? '' : label;
  }

  function findOptionByValue(select, value) {
    if (!select || !select.options) return null;
    const normalizedValue = String(value || '');
    for (let index = 0; index < select.options.length; index += 1) {
      if (String(select.options[index].value || '') === normalizedValue) {
        return select.options[index];
      }
    }
    return null;
  }

  function findOptionByLabel(select, label) {
    if (!select || !select.options) return null;
    const normalizedLabel = normalizeLabel(label);
    if (!normalizedLabel) return null;

    for (let index = 0; index < select.options.length; index += 1) {
      if (normalizeLabel(select.options[index].textContent || '') === normalizedLabel) {
        return select.options[index];
      }
    }
    return null;
  }

  function ensureSelectedOption(select, value, label) {
    if (!select) return null;

    let option = null;
    if (value !== undefined && value !== null && String(value) !== '') {
      option = findOptionByValue(select, value);
    }
    if (!option && label) {
      option = findOptionByLabel(select, label);
    }

    if (!option) {
      option = createOption(String(value || ''), String(label || value || ''), true);
      select.appendChild(option);
    }

    option.selected = true;
    select.value = String(option.value || '');
    return option;
  }

  function prefillSavedSelections(savedAddress) {
    if (!savedAddress) return;

    const deptSelect = ensureDepartmentSelect();
    const municipalitySelect = getMunicipalitySelect();

    if (deptSelect && savedAddress.department) {
      ensureSelectedOption(deptSelect, savedAddress.stateId, savedAddress.department);
    }

    if (municipalitySelect && savedAddress.city) {
      ensureSelectedOption(municipalitySelect, savedAddress.city, savedAddress.city);
      municipalitySelect.disabled = false;
    }
  }

  function buildDepartmentsFromSelect(select) {
    if (!select || !select.options) {
      return [];
    }

    const seen = Object.create(null);
    const departments = [];

    for (let index = 0; index < select.options.length; index += 1) {
      const option = select.options[index];
      const name = String(option.textContent || '').trim();
      const id = String(option.value || '').trim();

      if (isDepartmentPlaceholder(name)) {
        continue;
      }

      const key = normalizeLabel(name);
      if (!key || seen[key]) {
        continue;
      }

      seen[key] = true;
      departments.push({ id: id, name: name });
    }

    return departments;
  }

  function getDepartmentSource(preselect) {
    if (departmentsCache.length > 0) {
      return departmentsCache.slice();
    }

    if (CONFIG && Array.isArray(CONFIG.departments) && CONFIG.departments.length > 0) {
      Array.prototype.push.apply(departmentsCache, CONFIG.departments);
      return departmentsCache.slice();
    }

    const nativeOptions = buildDepartmentsFromSelect(getNativeDepartmentSelect());
    if (nativeOptions.length > 0) {
      Array.prototype.push.apply(departmentsCache, nativeOptions);
      return departmentsCache.slice();
    }

    if (preselect && preselect.name) {
      return [{ id: String(preselect.id || ''), name: String(preselect.name) }];
    }

    return [];
  }

  function getDepartmentFieldName() {
    const nativeSelect = getNativeDepartmentSelect();
    if (nativeSelect && nativeSelect.name) {
      return nativeSelect.name;
    }

    const countrySelect = getCountrySelect();
    if (countrySelect && countrySelect.name && countrySelect.name.indexOf('address[') === 0) {
      return 'address[id_state]';
    }

    return 'id_state';
  }

  function getInitialDepartmentSelection() {
    const deptSelect = getDepartmentSelect();
    if (!deptSelect) {
      return { id: '', name: '' };
    }

    const selectedName = getSelectedDepartmentName(deptSelect);
    const selectedId = String(deptSelect.value || '').trim();

    return {
      id: selectedName ? selectedId : '',
      name: selectedName,
    };
  }

  function getHydrationKey(colombia, departmentSelection, cityValue) {
    if (!colombia) {
      return 'country:other';
    }

    const departmentId = departmentSelection && departmentSelection.id ? String(departmentSelection.id) : '';
    const departmentName = departmentSelection && departmentSelection.name ? String(departmentSelection.name) : '';
    const city = cityValue ? String(cityValue) : '';
    const addressId = CONFIG && CONFIG.currentAddressId ? String(CONFIG.currentAddressId) : '';

    return ['country:co', departmentId, departmentName, city, addressId].join('|');
  }

  function isColombiaSelected() {
    const countrySelect = getCountrySelect();
    if (!countrySelect) return null;

    const selected = countrySelect.options[countrySelect.selectedIndex];
    const code = (selected && selected.dataset && selected.dataset.isoCode) ? String(selected.dataset.isoCode).toUpperCase() : '';
    const text = selected ? String(selected.textContent || '').trim().toLowerCase() : '';
    const value = String(countrySelect.value || '');
    const colombiaCountryId = CONFIG && CONFIG.colombiaCountryId ? String(CONFIG.colombiaCountryId) : '';

    return (
      code === 'CO' ||
      (colombiaCountryId !== '' && value === colombiaCountryId) ||
      value === '69' ||
      text.indexOf('colombia') !== -1
    );
  }

  function ensureDepartmentSelect() {
    const nativeSelect = getNativeDepartmentSelect();
    if (nativeSelect) return nativeSelect;

    let select = getDynamicDepartmentSelect();
    if (select) return select;

    const cityField = getCityField();
    if (!cityField) return null;

    const cityContainer = cityField.closest('.form-group') || cityField.parentNode;
    if (!cityContainer || !cityContainer.parentNode) return null;

    const wrapper = document.createElement('div');
    wrapper.className = 'form-group row colombia-department-group';

    const labelCol = document.createElement('label');
    labelCol.className = 'col-md-3 form-control-label required';
    labelCol.setAttribute('for', 'colombia_department');
    labelCol.textContent = 'Departamento';

    const inputCol = document.createElement('div');
    inputCol.className = 'col-md-6 js-input-column';

    select = document.createElement('select');
    select.id = 'id_state';
    select.name = getDepartmentFieldName();
    select.className = 'form-control form-control-select';
    select.setAttribute('data-colombia-department', '1');
    select.appendChild(createOption('', '— Seleccione un departamento —'));

    inputCol.appendChild(select);
    wrapper.appendChild(labelCol);
    wrapper.appendChild(inputCol);

    cityContainer.parentNode.insertBefore(wrapper, cityContainer);

    return select;
  }

  function getDynamicDepartmentSelect() {
    return document.querySelector('[data-colombia-department]');
  }

  function getDynamicDepartmentGroup() {
    return document.querySelector('.colombia-department-group');
  }

  function getDynamicMunicipalityGroup() {
    return document.querySelector('.colombia-municipality-group');
  }

  function getCityMunicipalitySelect() {
    return document.querySelector('select[data-colombia-city-select]');
  }

  function setColombiaUiVisible(visible) {
    const deptGroup = getDynamicDepartmentGroup();
    const muniGroup = getDynamicMunicipalityGroup();
    const cityField = getCityField();
    const citySelect = getCityMunicipalitySelect();

    if (deptGroup) {
      deptGroup.style.display = visible ? '' : 'none';
    }
    if (muniGroup) {
      muniGroup.style.display = visible ? '' : 'none';
    }

    if (cityField) {
      const canHideCityField = !visible || Boolean(citySelect);
      cityField.style.display = (visible && canHideCityField) ? 'none' : '';
      cityField.disabled = (visible && canHideCityField);
    }
    if (citySelect) {
      citySelect.style.display = visible ? '' : 'none';
      citySelect.disabled = !visible;
    }
  }

  function setNativeDepartmentVisible(visible) {
    const nativeSelect = getNativeDepartmentSelect();
    if (!nativeSelect) {
      const dynamicGroup = getDynamicDepartmentGroup();
      if (dynamicGroup && dynamicGroup.style) {
        dynamicGroup.style.display = visible ? '' : 'none';
      }
      return;
    }

    const nativeGroup = nativeSelect.closest('.form-group') || nativeSelect.parentNode;
    if (nativeGroup && nativeGroup.style) {
      nativeGroup.style.display = visible ? '' : 'none';
    }
  }

  /**
   * Return the Colombian municipality <select> added by the Symfony form modifier.
   *
   * @returns {HTMLSelectElement|null}
   */
  function getMunicipalitySelect() {
    const existing = (
      getCityMunicipalitySelect() ||
      document.querySelector('[data-colombia-municipality]') ||
      document.querySelector('select[name="colombia_municipality"]') ||
      document.querySelector('select[name="address[colombia_municipality]"]') ||
      null
    );

    if (existing) return existing;

    return ensureMunicipalitySelect();
  }

  /**
   * Return the native city field.
   *
   * @returns {HTMLInputElement|null}
   */
  function getCityField() {
    return (
      document.querySelector('input[name="city"]') ||
      document.querySelector('input[name="address[city]"]') ||
      document.querySelector('#city') ||
      null
    );
  }

  /**
   * Return the postal-code input.
   *
   * @returns {HTMLInputElement|null}
   */
  function getPostalCodeField() {
    return (
      document.querySelector('input[name="postcode"]') ||
      document.querySelector('input[name="address[postcode]"]') ||
      document.querySelector('#postcode') ||
      null
    );
  }

  /**
   * Return the hidden DANE code input added by the form modifier.
   *
   * @returns {HTMLInputElement|null}
   */
  function getDaneCodeField() {
    const existing = (
      document.querySelector('[data-colombia-dane-code]') ||
      document.querySelector('input[name="colombia_dane_code"]') ||
      document.querySelector('input[name="address[colombia_dane_code]"]') ||
      null
    );

    if (existing) return existing;

    return ensureDaneCodeField();
  }

  /**
   * Create municipality select dynamically when the form hook did not
   * inject it (theme/custom form compatibility fallback).
   *
   * @returns {HTMLSelectElement|null}
   */
  function ensureMunicipalitySelect() {
    const cityField = getCityField();
    if (!cityField || !cityField.parentNode) return null;

    const existing = getCityMunicipalitySelect();
    if (existing) return existing;

    const select = document.createElement('select');
    select.id = 'colombia_city_select';
    select.name = cityField.name || 'city';
    select.className = 'form-control form-control-select colombia-municipality-select';
    select.setAttribute('data-colombia-city-select', '1');
    select.setAttribute('data-autofill-postal', CONFIG.autofillPostal ? '1' : '0');
    select.appendChild(createOption('', '— Seleccione un municipio —'));

    cityField.parentNode.insertBefore(select, cityField.nextSibling);
    cityField.style.display = 'none';

    return select;
  }

  /**
   * Create hidden DANE code field when missing.
   *
   * @returns {HTMLInputElement|null}
   */
  function ensureDaneCodeField() {
    const cityField = getCityField();
    if (!cityField || !cityField.form) return null;

    const hidden = document.createElement('input');
    hidden.type = 'hidden';
    hidden.name = 'colombia_dane_code';
    hidden.setAttribute('data-colombia-dane-code', '1');

    cityField.form.appendChild(hidden);

    return hidden;
  }

  // ── Utilities ──────────────────────────────────────────────────────────

  /**
   * Escape a string so it is safe to use as text content in the DOM.
   * Never use innerHTML with this — use textContent or createTextNode instead.
   *
   * @param {string} str
   * @returns {string}
   */
  function escapeHtml(str) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
    return String(str).replace(/[&<>"']/g, function (c) { return map[c]; });
  }

  /**
   * Create a single <option> element safely (no innerHTML).
   *
   * @param {string} value
   * @param {string} label
   * @param {boolean} [selected=false]
   * @returns {HTMLOptionElement}
   */
  function createOption(value, label, selected) {
    const opt = document.createElement('option');
    opt.value       = value;
    opt.textContent = label;        // textContent is XSS-safe
    if (selected) opt.selected = true;
    return opt;
  }

  function parseJsonResponse(response) {
    return response.text().then(function (body) {
      const raw = String(body || '');

      try {
        return JSON.parse(raw);
      } catch (firstError) {
        const objectStart = raw.indexOf('{');
        const arrayStart = raw.indexOf('[');
        let start = -1;

        if (objectStart !== -1 && arrayStart !== -1) {
          start = Math.min(objectStart, arrayStart);
        } else {
          start = objectStart !== -1 ? objectStart : arrayStart;
        }

        const objectEnd = raw.lastIndexOf('}');
        const arrayEnd = raw.lastIndexOf(']');
        const end = Math.max(objectEnd, arrayEnd);

        if (start === -1 || end === -1 || end < start) {
          throw firstError;
        }

        return JSON.parse(raw.slice(start, end + 1));
      }
    });
  }

  // ── State ──────────────────────────────────────────────────────────────

  /** In-memory cache to avoid duplicate AJAX calls per page load. */
  const municipalitiesCache = Object.create(null);
  const departmentsCache = [];
  const SELECT_INTERACTION_LOCK_MS = 700;
  let selectInteractionLockUntil = 0;
  let pendingInitRetryTimer = null;

  function isAddressSelectElement(el) {
    if (!el || el.tagName !== 'SELECT') {
      return false;
    }

    return Boolean(
      el.matches('select[name="id_country"]') ||
      el.matches('select[name="address[id_country]"]') ||
      el.matches('select[name="id_state"]') ||
      el.matches('select[name="address[id_state]"]') ||
      el.matches('[data-colombia-city-select]') ||
      el.id === 'id_country' ||
      el.id === 'id_state'
    );
  }

  function isAddressSelectFocused() {
    const active = document.activeElement;
    return isAddressSelectElement(active);
  }

  function lockSelectInteraction() {
    selectInteractionLockUntil = Date.now() + SELECT_INTERACTION_LOCK_MS;
  }

  function shouldSkipReinitNow() {
    return isAddressSelectFocused() || Date.now() < selectInteractionLockUntil;
  }

  function triggerReinit() {
    if (shouldSkipReinitNow()) {
      setTimeout(triggerReinit, 180);
      return;
    }

    init();
  }

  function hasDepartmentAndMunicipalityControls() {
    const deptSelect = getDepartmentSelect();
    const citySelect = getCityMunicipalitySelect();
    return Boolean(deptSelect && citySelect);
  }

  function scheduleInitRetry(delayMs) {
    if (pendingInitRetryTimer !== null) {
      return;
    }

    pendingInitRetryTimer = setTimeout(function () {
      pendingInitRetryTimer = null;
      triggerReinit();
    }, delayMs);
  }

  function shouldHydrateFromSavedCity(savedCity) {
    const deptSelect = getDepartmentSelect();
    const municipalitySelect = getMunicipalitySelect();
    if (!savedCity) return false;
    if (!deptSelect) return true;
    if (!getSelectedDepartmentName(deptSelect)) return true;
    if (!deptSelect.value) return true;
    if (!municipalitySelect) return false;
    return !municipalitySelect.value;
  }

  function lookupMunicipality(savedCity) {
    if (!savedCity) {
      return Promise.resolve(null);
    }

    const url = new URL(CONFIG.baseUrl, window.location.href);
    url.searchParams.set('lookup', 'municipality');
    url.searchParams.set('municipality', savedCity);
    url.searchParams.set('token', CONFIG.token);

    return fetch(url.toString(), {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      credentials: 'same-origin',
    })
      .then(function (response) {
        if (!response.ok) {
          return null;
        }
        return parseJsonResponse(response);
      })
      .catch(function () {
        return null;
      });
  }

  function lookupAddress(addressId) {
    if (!addressId) {
      return Promise.resolve(null);
    }

    const url = new URL(CONFIG.baseUrl, window.location.href);
    url.searchParams.set('lookup', 'address');
    url.searchParams.set('id_address', String(addressId));
    url.searchParams.set('token', CONFIG.token);

    return fetch(url.toString(), {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      credentials: 'same-origin',
    })
      .then(function (response) {
        if (!response.ok) {
          return null;
        }
        return parseJsonResponse(response);
      })
      .catch(function () {
        return null;
      });
  }

  function getConfiguredSavedAddress() {
    if (!CONFIG || !CONFIG.savedAddress || typeof CONFIG.savedAddress !== 'object') {
      return null;
    }

    const city = String(CONFIG.savedAddress.city || '').trim();
    const department = String(CONFIG.savedAddress.department || '').trim();
    const stateId = String(CONFIG.savedAddress.state_id || '').trim();

    if (!city && !department && !stateId) {
      return null;
    }

    return {
      city: city,
      department: department,
      stateId: stateId,
    };
  }

  function findDepartmentStateIdByName(departmentName) {
    const target = normalizeLabel(departmentName);
    if (!target || !CONFIG || !Array.isArray(CONFIG.departments)) {
      return '';
    }

    for (let index = 0; index < CONFIG.departments.length; index += 1) {
      const department = CONFIG.departments[index] || {};
      if (normalizeLabel(department.name || '') === target) {
        return String(department.id || '');
      }
    }

    return '';
  }

  function loadDepartments(preselect, preselectMunicipality) {
    const deptSelect = ensureDepartmentSelect();
    if (!deptSelect) return;

    preselect = preselect || {};
    preselectMunicipality = preselectMunicipality || '';

    const departments = getDepartmentSource(preselect);
    deptSelect.disabled = false;
    populateDepartments(deptSelect, departments, preselect);

    if (departments.length === 0 && preselect && (preselect.id || preselect.name)) {
      ensureSelectedOption(deptSelect, preselect.id, preselect.name);
    }

    const selectedDepartmentName = getSelectedDepartmentName(deptSelect) || String(preselect.name || '');
    if (selectedDepartmentName) {
      loadMunicipalities(selectedDepartmentName, preselectMunicipality);
    }
  }

  function populateDepartments(selectEl, departments, preselect) {
    const expectedName = normalizeLabel(preselect && preselect.name ? preselect.name : '');
    selectEl.innerHTML = '';
    selectEl.appendChild(createOption('', '— Seleccione un departamento —'));

    departments.forEach(function (department) {
      const id = String((department && department.id) || '');
      const name = String((department && department.name) || '');
      const isSelected = (
        (preselect.id && id === String(preselect.id)) ||
        (expectedName && normalizeLabel(name) === expectedName)
      );

      selectEl.appendChild(createOption(id, name, isSelected));
    });
  }

  // ── Core logic ─────────────────────────────────────────────────────────

  /**
   * Fetch municipalities for a department and populate the select element.
   *
   * @param {string} departmentName  Human-readable department name (e.g. "Antioquia")
   * @param {string} [preselect=''] Municipality to pre-select after loading
   */
  function loadMunicipalities(departmentName, preselect) {
    if (!departmentName) return;

    preselect = preselect || '';

    const municipalitySelect = getMunicipalitySelect();
    if (!municipalitySelect) return;

    // Use cache if available.
    if (municipalitiesCache[departmentName]) {
      populateSelect(municipalitySelect, municipalitiesCache[departmentName], preselect);
      return;
    }

    // Show loading state.
    municipalitySelect.disabled = true;
    municipalitySelect.innerHTML = '';
    municipalitySelect.appendChild(createOption('', 'Cargando…'));

    // Build the AJAX URL, appending the security token.
    const url = new URL(CONFIG.baseUrl, window.location.href);
    url.searchParams.set('department', departmentName);
    url.searchParams.set('token', CONFIG.token);

    fetch(url.toString(), {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      credentials: 'same-origin',
    })
      .then(function (response) {
        if (!response.ok) {
          throw new Error('HTTP ' + response.status);
        }
        return parseJsonResponse(response);
      })
      .then(function (data) {
        if (!data || !Array.isArray(data.municipalities)) {
          throw new Error('Unexpected response format');
        }

        // Store in cache.
        municipalitiesCache[departmentName] = data.municipalities;

        populateSelect(municipalitySelect, data.municipalities, preselect);
        municipalitySelect.disabled = false;
      })
      .catch(function (err) {
        console.error('[ps_colombia_address] Failed to load municipalities:', err);
        municipalitySelect.innerHTML = '';
        municipalitySelect.appendChild(createOption('', '— Error al cargar —'));
        municipalitySelect.disabled = false;
      });
  }

  /**
   * Fill the municipality <select> with an array of municipality objects.
   *
   * @param {HTMLSelectElement} selectEl
   * @param {Array<{name:string,postal_code:string,dane_code:string,latitude:string,longitude:string}>} municipalities
   * @param {string} preselect
   */
  function populateSelect(selectEl, municipalities, preselect) {
    selectEl.innerHTML = '';
    selectEl.appendChild(createOption('', '— Seleccione un municipio —'));

    municipalities.forEach(function (m) {
      const opt = createOption(m.name, m.name, m.name === preselect);
      // Store extra data as data attributes on the option element.
      opt.dataset.postalCode = m.postal_code;
      opt.dataset.daneCode   = m.dane_code;
      opt.dataset.lat        = m.latitude;
      opt.dataset.lon        = m.longitude;
      selectEl.appendChild(opt);
    });

    // If preselect was set, trigger change to auto-fill fields.
    if (preselect) {
      ensureSelectedOption(selectEl, preselect, preselect);
      onMunicipalityChange({ target: selectEl });
    }
  }

  /**
   * Handle municipality selection change.
   * Syncs city, postal_code, and DANE code fields.
   *
   * @param {Event} event
   */
  function onMunicipalityChange(event) {
    const select = event.target;
    const selected = select.options[select.selectedIndex];

    const cityField     = getCityField();
    const postalField   = getPostalCodeField();
    const daneCodeField = getDaneCodeField();

    // Sync city (always)
    if (cityField) {
      cityField.value = selected ? (selected.value || '') : '';
    }

    // Autofill postal code if enabled
    if (CONFIG.autofillPostal && postalField && selected) {
      const postal = selected.dataset.postalCode || '';
      if (postal) {
        postalField.value = postal;
      }
    }

    // Store DANE code if logistics mode is enabled
    if (CONFIG.logisticsMode && daneCodeField && selected) {
      daneCodeField.value = selected.dataset.daneCode || '';
    }
  }

  /**
   * Handle department/state selection change.
   * Derives the department name from the selected <option> text.
   *
   * @param {Event} event
   */
  function onDepartmentChange(event) {
    if (isColombiaSelected() !== true) {
      return;
    }

    const select  = event.target;
    const selected = select.options[select.selectedIndex];
    const deptName = selected ? (selected.textContent || '').trim() : '';

    // Reset municipality and city / postal / DANE when department changes.
    const municipalitySelect = getMunicipalitySelect();
    const cityField          = getCityField();
    const postalField        = getPostalCodeField();
    const daneCodeField      = getDaneCodeField();

    if (municipalitySelect) {
      municipalitySelect.innerHTML = '';
      municipalitySelect.appendChild(createOption('', '— Seleccione un municipio —'));
    }
    if (cityField)     cityField.value     = '';
    if (daneCodeField) daneCodeField.value = '';
    // Do not clear postal code automatically; user may have typed it.

    if (deptName) {
      loadMunicipalities(deptName);
    }
  }

  // ── Initialisation ─────────────────────────────────────────────────────

  /**
   * Attach all event listeners.
   * Safe to call multiple times (e.g. after checkout AJAX refresh).
   */
  function init() {
    const countrySelect = getCountrySelect();
    const colombia = isColombiaSelected();

    if (!countrySelect || colombia === null) {
      // Theme/checkout may render country select asynchronously.
      // Keep controls available and retry shortly instead of hiding them.
      setNativeDepartmentVisible(true);
      setColombiaUiVisible(true);
      ensureDepartmentSelect();
      getMunicipalitySelect();
      scheduleInitRetry(250);
      return;
    }

    const cityField = getCityField();
    const preselectedCity = cityField ? String(cityField.value || '').trim() : '';
    const preselectedDepartment = getInitialDepartmentSelection();
    const currentAddressId = CONFIG && CONFIG.currentAddressId ? parseInt(CONFIG.currentAddressId, 10) : 0;
    const configuredSavedAddress = getConfiguredSavedAddress();

    prefillSavedSelections(configuredSavedAddress);

    hideOptionalAddressFields();
    reorderAddressGroups();

    if (!colombia) {
      setNativeDepartmentVisible(true);
      setColombiaUiVisible(false);
      return;
    }

    setNativeDepartmentVisible(true);
    setColombiaUiVisible(true);

    const deptSelect = ensureDepartmentSelect();

    if (!deptSelect) return;

    const hydrationKey = getHydrationKey(colombia, preselectedDepartment, preselectedCity);

    const runInitialHydration = function () {
      const hasReliableDepartment = Boolean(preselectedDepartment && preselectedDepartment.name);

      if (hasReliableDepartment) {
        loadDepartments(preselectedDepartment, preselectedCity);
        return;
      }

      if (configuredSavedAddress && (configuredSavedAddress.department || configuredSavedAddress.city)) {
        if (configuredSavedAddress.department) {
          loadDepartments({
            id: configuredSavedAddress.stateId,
            name: configuredSavedAddress.department,
          }, configuredSavedAddress.city);
          return;
        }

        if (configuredSavedAddress.city) {
          lookupMunicipality(configuredSavedAddress.city).then(function (data) {
            if (!data || !data.department) {
              loadDepartments({ id: '', name: '' }, configuredSavedAddress.city);
              return;
            }

            loadDepartments({
              id: String(data.state_id || findDepartmentStateIdByName(data.department) || ''),
              name: String(data.department || ''),
            }, String(data.municipality || configuredSavedAddress.city || ''));
          });
          return;
        }
      }

      if (!preselectedCity) {
        if (currentAddressId > 0) {
          lookupAddress(currentAddressId).then(function (addressData) {
            if (!addressData || (!addressData.city && !addressData.department)) {
              loadDepartments({ id: '', name: '' }, '');
              return;
            }

            if (addressData.department) {
              loadDepartments({
                id: String(addressData.state_id || ''),
                name: String(addressData.department || ''),
              }, String(addressData.city || ''));
              return;
            }

            if (addressData.city) {
              lookupMunicipality(String(addressData.city)).then(function (data) {
                if (!data || !data.department) {
                  loadDepartments({ id: '', name: '' }, String(addressData.city || ''));
                  return;
                }

                loadDepartments({
                  id: String(data.state_id || findDepartmentStateIdByName(data.department) || ''),
                  name: String(data.department || ''),
                }, String(data.municipality || addressData.city || ''));
              });
              return;
            }

            loadDepartments({ id: '', name: '' }, '');
          });
          return;
        }

        loadDepartments({ id: '', name: '' }, '');
        return;
      }

      if (!shouldHydrateFromSavedCity(preselectedCity)) {
        loadDepartments({ id: '', name: '' }, '');
        return;
      }

      lookupMunicipality(preselectedCity).then(function (data) {
        if (!data || !data.department) {
          loadDepartments({ id: '', name: '' }, preselectedCity);
          return;
        }

        loadDepartments({
          id: String(data.state_id || findDepartmentStateIdByName(data.department) || ''),
          name: String(data.department || ''),
        }, String(data.municipality || preselectedCity || ''));
      });
    };

    // Avoid double-binding AND prevent infinite loop caused by MutationObserver:
    // loadDepartments() modifies the DOM (options), which would re-trigger the
    // observer → init() → loadDepartments() → observer → ... freeze.
    if (deptSelect.dataset.colombiaInit === '1') {
      if (deptSelect.dataset.colombiaHydrationKey === hydrationKey) {
        return;
      }
      deptSelect.dataset.colombiaHydrationKey = hydrationKey;
      runInitialHydration();
      return;
    }
    deptSelect.dataset.colombiaInit = '1';
    deptSelect.dataset.colombiaHydrationKey = hydrationKey;

    runInitialHydration();

    deptSelect.addEventListener('change', onDepartmentChange);

    if (countrySelect && countrySelect.dataset.colombiaInit !== '1') {
      countrySelect.dataset.colombiaInit = '1';
      countrySelect.addEventListener('change', function () {
        const departmentSelect = getDepartmentSelect();
        if (departmentSelect && departmentSelect.dataset) {
          delete departmentSelect.dataset.colombiaHydrationKey;
        }

        if (isColombiaSelected() === true) {
          setNativeDepartmentVisible(true);
          setColombiaUiVisible(true);
          init();
        } else {
          setNativeDepartmentVisible(true);
          setColombiaUiVisible(false);
        }
      });
    }

    const municipalitySelect = getMunicipalitySelect();
    if (municipalitySelect && municipalitySelect.dataset.colombiaMuniBound !== '1') {
      municipalitySelect.dataset.colombiaMuniBound = '1';
      municipalitySelect.addEventListener('change', onMunicipalityChange);
    }

    // Initial municipalities load is handled by loadDepartments(preselectDept, preselectCity).
  }

  // ── Bootstrap ──────────────────────────────────────────────────────────

  // Standard DOM-ready + PrestaShop checkout AJAX re-init.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Some production themes inject/update address fields after first paint.
  // Run one delayed init pass to ensure hydration on edit forms.
  setTimeout(init, 350);

  // Watchdog for asynchronous/late-rendered address forms in production themes.
  // Retries a few times to guarantee both department and municipality controls exist.
  (function bootstrapWatchdog() {
    let attempts = 0;
    const maxAttempts = 18;
    const timer = setInterval(function () {
      attempts += 1;

      if (hasDepartmentAndMunicipalityControls()) {
        clearInterval(timer);
        return;
      }

      triggerReinit();

      if (attempts >= maxAttempts) {
        clearInterval(timer);
      }
    }, 250);
  }());

  // PrestaShop fires this custom event after checkout sections are refreshed.
  document.addEventListener('updatedAddressForm', triggerReinit);
  document.addEventListener('addressFormUpdated', triggerReinit);

  // Also re-init when PrestaShop fires the generic prestashop:* events.
  document.addEventListener('prestashop:payment-updated', triggerReinit);

  // Lock re-init briefly when the user starts interacting with address selects.
  document.addEventListener('pointerdown', function (event) {
    if (isAddressSelectElement(event.target)) {
      lockSelectInteraction();
    }
  }, true);

  document.addEventListener('focusin', function (event) {
    if (isAddressSelectElement(event.target)) {
      lockSelectInteraction();
    }
  });

  const formHost = document.querySelector('.js-address-form') || document.body;
  if (formHost && typeof MutationObserver !== 'undefined') {
    let mutationDebounceTimer = null;
    const observer = new MutationObserver(function () {
      if (shouldSkipReinitNow()) {
        return;
      }
      clearTimeout(mutationDebounceTimer);
      mutationDebounceTimer = setTimeout(triggerReinit, 150);
    });
    observer.observe(formHost, { childList: true, subtree: true });
  }

  // Expose re-init for third-party modules / themes.
  window.ColombiaAddress = { init: init, loadMunicipalities: loadMunicipalities };
}());
